const express= require('express');

const app= express();

const productRouter= require('./api/routes/products')

const orderRouter= require('./api/routes/orders')

const userRouter= require('./api/routes/users')

const morgan= require('morgan')

const bodyParser= express.urlencoded({extended: false})

const bodyParserjson= express.json();

app.use('/uploads', express.static('uploads'));
//The above line makes the uploads folder publicly accessible

const mongoose= require('mongoose');
mongoose.connect('*Connection Link to Database*', {
  useNewUrlParser: true,
	useUnifiedTopology: true,
}).catch(err=>{
  console.log(err);
});

mongoose.Promise= global.Promise;
app.use(morgan('dev'));

app.use(bodyParser);

app.use(bodyParserjson);

//The below allows CORS
app.use((req, res, next)=>{
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  //The browser always sends an Options request to check if it can send a subsequent GET, POST, PUT, DELETE Request
  if(req.method==='OPTIONS'){
    res.header('Access-Control-Allow-Methods', 'GET, PUT, POST, PATCH, DELETE');
    res.status(200).json({});
  }
  //Now we call next, this is important as we're blocking the req/res right now, by calling next, we forward it to the actual requests
  next();
})

app.use('/products', productRouter);

app.use('/orders', orderRouter);

app.use('/users', userRouter);

//Now to handle errors, we realize that if a request made it till this point, that means it wasn't a valid request, so we can
//collect them all

app.use((req, res, next)=>{
  const error= new Error('Not found');
  error.status= 404;
  next(error);
})

app.use((error, req, res, next)=>{
  res.status(error.status || 500).json({
    error: {
      message: error.message
    }
  })
})


module.exports= app;
