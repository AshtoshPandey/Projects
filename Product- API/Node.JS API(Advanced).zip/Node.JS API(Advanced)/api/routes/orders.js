const express= require('express');
const router= express.Router();
const mongoose= require('mongoose');
const Order= require('../models/orderSchema');
const Product= require('../models/productSchema');
const check_Auth= require('../middleware/check_auth');


router.get('/', (req, res, next)=>{
  Order.find().select('product quantity _id').populate('product').exec().then(docs=>{
    const createdDoc= {
      count: docs.length,
      products: docs.map((doc)=>{
        return {
          quantity: doc.quantity,
          _id: doc._id,
          product: doc.product,
          url: {
            req: 'GET',
            address: 'localhost:3000/products/'+ doc._id
        }
        }
      })
    }
    res.status(200).json(createdDoc);
  }).catch(err=>{
    res.status(500).json({error: err});
  });
});


router.post('/', check_Auth, (req, res, next)=>{
  Product.findById(req.body.product).exec().then(doc=>{
    if(doc){
      const createdOrder= new Order({
        _id: mongoose.Types.ObjectId(),
        product: req.body.product,
        quantity: req.body.quantity
      });
      createdOrder.save().then(result=>{
        res.status(201).json({
          message: 'Order created successfully.',
          result: {
            id: result._id,
            quantity: result.quantity,
            product: result.product,
            url: {
              request: 'GET',
              address: 'localhost:3000/orders/'+ result._id,
              prodAddress: 'localhost:3000/products/'+ createdOrder.productId
            }
          }
        })
      }).catch(err=>{
        res.status(500).json({
          message: 'Could not be done',
          error: err
        })
      })
    } else{
      res.status(500).json({
        message: 'The product does not exist'
      })
    }
  }).catch(err=>{
    res.status(500).json({
      message: 'Unsuccessful',
      error: err
    })
  })
});

router.get('/:orderId', check_Auth, (req, res, next)=>{
  const id= req.params.orderId;
  Order.findById(id).populate('product').select('quantity product _id').exec()
  .then(doc=>{
    if(doc){
      res.status(200).json(doc);
    }else{
      res.status(404).json({error: "This document does not exist"});
    }
  }).catch(err=>{
    res.status(500).json({error: err});
  });
});

router.delete('/:orderId', check_Auth, (req, res, next)=>{
  const id= req.params.orderId;
  Order.findById(id).exec().then(doc=>{
    if(doc){
      Order.remove({ _id: id}).exec();
      res.status(201).json({
        message: 'Order deleted successfully'
      })
    } else{
      res.status(500).json({
        message: 'Order does not exist'
      })
    }
  })
});


module.exports= router;
