const express= require('express');
const router= express.Router();
const mongoose= require('mongoose');
const User= require('../models/usersSchema');
const bcrypt= require('bcrypt');
const jwt= require('jsonwebtoken');
const pvtkey= "superSecretKey";

router.post('/signup', (req, res, body)=>{
  User.find({email: req.body.email}).exec().then(user=>{
    if(user.length>=1){
      res.status(409).json({
        message: 'User already exists'
      })
    } else{
        bcrypt.hash(req.body.password, 10, (err,hash)=>{
          if(err){
            res.status(500).json({
              error: err
            })
          } else{
            const createdUser= new User({
              _id: mongoose.Types.ObjectId(),
              email: req.body.email,
              password: hash
            });
            createdUser.save()
            .then(result=>{
              res.status(201).json({
                message: 'User created successfully',
                user: req.body.email
              })
            })
            .catch(err=>{
              res.status(500).json({
                error: err
              })
            });
          }
        })
      }
    })
  });


router.post('/signin', (req, res, next)=>{
  User.find({ email: req.body.email})
  .exec()
  .then(users=>{
    if(users.length<1){
      res.status(401).json({
        message: 'Authorization failed'
      });
    } else{
      bcrypt.compare(req.body.password, users[0].password, (err, result)=>{
        if(err){
          res.status(401).json({
            message: 'Authorization failed'
          });
        }
        if (result){
          const token= jwt.sign({
            email: users[0].email,
            id: users[0]._id
          }, pvtkey, {
            expiresIn: "1h"
          });
          res.status(200).json({
            message: 'Authoriztion successful',
            token: token
          })
        } else{
          res.status(401).json({
            message: 'Authorization failed'
          });
        }
      })
    }
  })
  .catch(err=>{
    console.log(err);
    res.status(404).json({
      error: err
    })
  })
})


router.delete('/:userId', (req, res, next)=>{
  User.remove({_id: req.params.userId}).exec()
  .then(result=>{
    res.status(201).json({
      message: 'User deleted successfully'
    })
  })
  .catch(err=>{
    console.log(err);
    res.status(404).json({
      message: 'User not found'
    })
  })
});
module.exports= router;
