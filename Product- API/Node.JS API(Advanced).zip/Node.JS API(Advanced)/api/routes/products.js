const express= require('express');
const router= express.Router();
const mongoose= require('mongoose');
const Product= require('../models/productSchema');
const multer = require('multer');
const storage= multer.diskStorage({
  destination: function(req, file, cb){
    cb(null, './uploads/');
  },
  filename: function(req, file, cb){
    cb(null, file.originalname);
  }
});
const upload= multer({storage: storage});
const check_Auth= require('../middleware/check_auth');


router.get('/', (req, res, next)=>{
  Product.find().select('name price _id productImage').exec().then(docs=>{
    const createdDoc= {
      count: docs.length,
      products: docs.map((doc)=>{
        return {
          name: doc.name,
          _id: doc._id,
          price: doc.price,
          productImage: doc.productImage,
          url: {
            req: 'GET',
            address: 'localhost:3000/products/'+ doc._id
        }
        }
      })
    }
    res.status(200).json(createdDoc);
  }).catch(err=>{
    res.status(500).json({error: err});
  });
});

//Upload.single accesses only one file
router.post('/', upload.single('productImage'), check_Auth, (req, res, next)=>{
  console.log(req.file);
  const createdProduct= new Product({
    _id: new mongoose.Types.ObjectId(),
    name: req.body.name,
    price: req.body.price,
    productImage: req.file.path
  });
  createdProduct.save().then(result=>{
    console.log(result);
    res.status(201).json({
      message: "Product created successfully.",
      product: {
        name: createdProduct.name,
        _id: createdProduct._id,
        price: createdProduct.price,
        productImage: createdProduct.productImage,
        url: {
          req: 'GET',
          address: 'localhost:3000/products/'+ createdProduct._id
        }
      }
    });
  }).catch(err=>{
    console.log(err);
    res.status(500).json({error: err});
  });
});

router.get('/:productId', (req, res, next)=>{
  const id= req.params.productId;
  Product.findById(id).select('name price _id productImage').exec()
  .then(doc=>{
    if(doc){
      res.status(200).json(doc);
    }else{
      res.status(404).json({error: "This document does not exist"});
    }
  }).catch(err=>{
    res.status(500).json({error: err});
  });
});


router.patch('/:productId', check_Auth, (req, res, next)=>{
  const id= req.params.productId;
  const updateOps= {};
  for(const ops of req.body){
    updateOps[ops.propName]= ops.value;
  }
  Product.update({ _id: id}, { $set: updateOps })
  .exec()
  .then(result=>{
    res.status(201).json({
      message: "Product updated successfully",
      url: {
        req: 'GET',
        address: 'localhost:3000/products/'+ id
      }
    });
  })
  .catch(error=>{
    res.status(500).json({error: error});
  })
});


router.delete('/:productId', (req, res, next)=>{
  const id= req.params.productId;
  Product.findById(id).exec().then(doc=>{
    if(doc){
      Product.remove({ _id: id}).exec();
      res.status(201).json({
        message: 'Product deleted successfully'
      })
    } else{
      res.status(500).json({
        message: 'Product does not exist'
      })
    }
  })

});


module.exports= router;
