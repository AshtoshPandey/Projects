let express= require('express');

let todoController= require('./controller/todo-controller');

let app= express();

app.set('view engine', 'ejs');

app.use(express.static('./public'));
//By removing /assets, we're simply directing all the static requests to the public directory

//Firing the controllers
todoController(app);


app.listen(3000);
console.log("Listening to Port- 3000");
